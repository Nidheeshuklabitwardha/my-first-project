import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

export default function BlogList() {
    const [posts, setPosts] = useState([]);

    useEffect(() => {
        axios.get("/api/posts").then((res) => setPosts(res.data));
    }, []);

    return (
        <div>
            <h2>Blog Posts</h2>
            {posts.map((post) => (
                <Link to={`/post/${post.id}`} key={post.id}>
                    <h3>{post.title}</h3>
                </Link>
            ))}
        </div>
    );
}
